import { a as createComponent, f as renderComponent, e as renderTemplate, m as maybeRenderHead, b as addAttribute } from '../chunks/astro/server_C4BCxsMS.mjs';
import 'kleur/colors';
import { g as getCollection } from '../chunks/_astro_content_C0DCnmuU.mjs';
import { $ as $$Layout, a as $$PostListItem } from '../chunks/PostListItem_B_poanij.mjs';
/* empty css                                 */
export { renderers } from '../renderers.mjs';

const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const posts = await getCollection("blog");
  const categoryMap = /* @__PURE__ */ new Map();
  for (const post of posts) {
    (post.data.tags || []).forEach((tag) => {
      if (!categoryMap.has(tag)) categoryMap.set(tag, []);
      categoryMap.get(tag).push(post);
    });
  }
  const sortedCategories = Array.from(categoryMap.entries()).sort((a, b) => {
    const aLatest = Math.max(...a[1].map((p) => p.data.date.valueOf()));
    const bLatest = Math.max(...b[1].map((p) => p.data.date.valueOf()));
    return aLatest - bLatest;
  });
  const leftCategories = [];
  const rightCategories = [];
  let leftCount = 0;
  let rightCount = 0;
  const shownSlugs = /* @__PURE__ */ new Set();
  const categorySections = [];
  for (const [category, posts2] of sortedCategories) {
    const uniquePosts = posts2.sort((a, b) => b.data.date.valueOf() - a.data.date.valueOf()).filter((post) => {
      if (shownSlugs.has(post.slug)) return false;
      shownSlugs.add(post.slug);
      return true;
    }).slice(0, 5);
    if (uniquePosts.length === 0) continue;
    categorySections.push([category, uniquePosts]);
  }
  for (const section of categorySections) {
    if (leftCount <= rightCount) {
      leftCategories.push(section);
      leftCount += section[1].length;
    } else {
      rightCategories.push(section);
      rightCount += section[1].length;
    }
  }
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Not So Common Thoughts", "data-astro-cid-j7pv25f6": true }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="pt-8 sm:pt-16" data-astro-cid-j7pv25f6> <div class="max-w-7xl px-4 sm:px-8 md:px-12 lg:px-16" data-astro-cid-j7pv25f6> <div class="grid grid-cols-1 lg:grid-cols-2 gap-y-0 lg:gap-x-12" data-astro-cid-j7pv25f6>  <div data-astro-cid-j7pv25f6> ${leftCategories.map(([category, uniquePosts]) => {
    if (uniquePosts.length === 0) return null;
    return renderTemplate`<section class="mb-12 sm:mb-16"${addAttribute(category, "id")} data-astro-cid-j7pv25f6> <div class="mb-6 pb-2 border-b border-slate-200 dark:border-slate-700" data-astro-cid-j7pv25f6> <h2 class="text-lg font-serif text-slate-900 dark:text-slate-100" data-astro-cid-j7pv25f6>${category.split("-").map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join(" ")}</h2> </div> <div class="space-y-6 sm:space-y-8" data-astro-cid-j7pv25f6> ${uniquePosts.map((post) => renderTemplate`${renderComponent($$result2, "PostListItem", $$PostListItem, { "post": post, "data-astro-cid-j7pv25f6": true })}`)} </div> <div class="mt-6" data-astro-cid-j7pv25f6> <a${addAttribute(`/${category}`, "href")} class="text-sm font-normal text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300 transition-colors flex items-center gap-1" data-astro-cid-j7pv25f6>
See all ${category} posts
<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor" data-astro-cid-j7pv25f6> <path fill-rule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clip-rule="evenodd" data-astro-cid-j7pv25f6></path> </svg> </a> </div> </section>`;
  })} </div>  <div data-astro-cid-j7pv25f6> ${rightCategories.map(([category, uniquePosts]) => {
    if (uniquePosts.length === 0) return null;
    return renderTemplate`<section class="mb-12 sm:mb-16"${addAttribute(category, "id")} data-astro-cid-j7pv25f6> <div class="mb-6 pb-2 border-b border-slate-200 dark:border-slate-700" data-astro-cid-j7pv25f6> <h2 class="text-lg font-serif text-slate-900 dark:text-slate-100" data-astro-cid-j7pv25f6>${category.split("-").map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join(" ")}</h2> </div> <div class="space-y-6 sm:space-y-8" data-astro-cid-j7pv25f6> ${uniquePosts.map((post) => renderTemplate`${renderComponent($$result2, "PostListItem", $$PostListItem, { "post": post, "data-astro-cid-j7pv25f6": true })}`)} </div> <div class="mt-6" data-astro-cid-j7pv25f6> <a${addAttribute(`/${category}`, "href")} class="text-sm font-normal text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300 transition-colors flex items-center gap-1" data-astro-cid-j7pv25f6>
See all ${category} posts
<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor" data-astro-cid-j7pv25f6> <path fill-rule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clip-rule="evenodd" data-astro-cid-j7pv25f6></path> </svg> </a> </div> </section>`;
  })} </div> </div> </div> </div> ` })} `;
}, "/Users/alex/Library/Mobile Documents/com~apple~CloudDocs/Dev/NotSoCommonThoughts/src/pages/index.astro", void 0);

const $$file = "/Users/alex/Library/Mobile Documents/com~apple~CloudDocs/Dev/NotSoCommonThoughts/src/pages/index.astro";
const $$url = "";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
