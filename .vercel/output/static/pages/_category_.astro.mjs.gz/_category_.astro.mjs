import { c as createAstro, a as createComponent, f as renderComponent, e as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_C4BCxsMS.mjs';
import 'kleur/colors';
import { g as getCollection } from '../chunks/_astro_content_C0DCnmuU.mjs';
import { $ as $$Layout, a as $$PostListItem } from '../chunks/PostListItem_B_poanij.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro = createAstro("https://notsocommonthoughts.com");
async function getStaticPaths() {
  const posts = await getCollection("blog");
  const categories = [...new Set(posts.flatMap((post) => post.data.tags || ["uncategorized"]))];
  return categories.map((category) => {
    const categoryPosts = posts.filter(
      (post) => (post.data.tags || ["uncategorized"]).includes(category)
    );
    const sortedPosts = categoryPosts.sort((a, b) => b.data.date.valueOf() - a.data.date.valueOf());
    return {
      params: { category },
      props: { posts: sortedPosts, category }
    };
  });
}
const $$category = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$category;
  const { posts, category } = Astro2.props;
  const categoryName = category.split("-").map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Not So Common Thoughts" }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="p-8 sm:p-16"> <div class="max-w-2xl"> <!-- Mobile Header --> <div class="sm:hidden mb-8"> <div class="mb-6 pb-2 border-b border-slate-200 dark:border-slate-700"> <h1 class="text-lg font-serif text-slate-900 dark:text-slate-100">${categoryName}</h1> </div> </div> <!-- Desktop Header --> <div class="hidden sm:block mb-8"> <div class="mb-6 pb-2 border-b border-slate-200 dark:border-slate-700"> <h1 class="text-lg font-serif text-slate-900 dark:text-slate-100">${categoryName}</h1> </div> </div> <div class="space-y-6 sm:space-y-8"> ${posts.map((post) => renderTemplate`${renderComponent($$result2, "PostListItem", $$PostListItem, { "post": post })}`)} </div> </div> </div> ` })}`;
}, "/Users/alex/Library/Mobile Documents/com~apple~CloudDocs/Dev/NotSoCommonThoughts/src/pages/[category].astro", void 0);

const $$file = "/Users/alex/Library/Mobile Documents/com~apple~CloudDocs/Dev/NotSoCommonThoughts/src/pages/[category].astro";
const $$url = "/[category]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$category,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
