import { c as createAstro, a as createComponent, f as renderComponent, e as renderTemplate, m as maybeRenderHead, F as Fragment, b as addAttribute } from '../../chunks/astro/server_C4BCxsMS.mjs';
import 'kleur/colors';
import { g as getCollection } from '../../chunks/_astro_content_C0DCnmuU.mjs';
import { $ as $$Layout, a as $$PostListItem } from '../../chunks/PostListItem_B_poanij.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro = createAstro("https://notsocommonthoughts.com");
async function getStaticPaths() {
  const posts = await getCollection("blog");
  return posts.map((post) => ({
    params: { slug: post.slug },
    props: { post }
  }));
}
const $$ = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$;
  const { post } = Astro2.props;
  const { Content } = await post.render();
  const categories = post.data.tags || [];
  function getRelativeTime(date) {
    const now = /* @__PURE__ */ new Date();
    const diff = Math.floor((now - date) / 1e3);
    if (diff < 60) return `${diff} second${diff === 1 ? "" : "s"} ago`;
    if (diff < 3600) return `${Math.floor(diff / 60)} minute${Math.floor(diff / 60) === 1 ? "" : "s"} ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)} hour${Math.floor(diff / 3600) === 1 ? "" : "s"} ago`;
    if (diff < 2592e3) return `${Math.floor(diff / 86400)} day${Math.floor(diff / 86400) === 1 ? "" : "s"} ago`;
    if (diff < 31536e3) return `${Math.floor(diff / 2592e3)} month${Math.floor(diff / 2592e3) === 1 ? "" : "s"} ago`;
    return `${Math.floor(diff / 31536e3)} year${Math.floor(diff / 31536e3) === 1 ? "" : "s"} ago`;
  }
  const category = post.data.tags?.[0] || "uncategorized";
  category.split("-").map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
  const allPosts = await getCollection("blog");
  const relatedPosts = allPosts.filter((p) => p.slug !== post.slug && (p.data.tags || []).some((tag) => categories.includes(tag))).sort((a, b) => b.data.date.valueOf() - a.data.date.valueOf()).slice(0, 3);
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Not So Common Thoughts" }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="p-8 sm:p-16"> <article class="max-w-2xl"> <header class="mb-8 pr-8 sm:pr-0"> <h1 class="text-4xl font-serif text-slate-900 dark:text-slate-100 mb-4" style="line-height:1.2"> ${post.data.title} </h1> <div class="text-sm text-slate-600 dark:text-slate-400">
Posted ${getRelativeTime(post.data.date)} in ${categories.map((cat, i) => {
    const catName = cat.split("-").map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
    return renderTemplate`${renderComponent($$result2, "Fragment", Fragment, {}, { "default": async ($$result3) => renderTemplate` <a${addAttribute(`/${cat}`, "href")} class="text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300 transition-colors">${catName}</a> ${i < categories.length - 1 ? " \xB7 " : ""}` })}`;
  })} </div> </header> <div class="prose prose-lg dark:prose-invert prose-headings:font-serif prose-a:text-red-600 dark:prose-a:text-red-400 prose-a:no-underline hover:prose-a:underline prose-p:font-serif prose-li:font-serif prose-headings:text-slate-900 dark:prose-headings:text-slate-100 prose-p:text-slate-600 dark:prose-p:text-slate-400 prose-strong:text-slate-900 dark:prose-strong:text-slate-100 prose-code:text-slate-900 dark:prose-code:text-slate-100 prose-blockquote:text-slate-600 dark:prose-blockquote:text-slate-400 prose-ul:text-slate-600 dark:prose-ul:text-slate-400 prose-ol:text-slate-600 dark:prose-ol:text-slate-400 prose-li:text-slate-600 dark:prose-li:text-slate-400 max-w-none"> ${renderComponent($$result2, "Content", Content, {})} </div> <div class="flex justify-center my-12"> <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-red-600 dark:text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"> <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m-8-8h16"></path> </svg> </div> </article> ${relatedPosts.length > 0 && renderTemplate`<section class="max-w-2xl mt-16"> <div class="mb-6 pb-2 border-b border-slate-200 dark:border-slate-700"> <h2 class="text-lg font-serif text-slate-900 dark:text-slate-100">More posts</h2> </div> <div class="grid grid-cols-1 lg:grid-cols-2 gap-6"> ${relatedPosts.map((rp) => renderTemplate`${renderComponent($$result2, "PostListItem", $$PostListItem, { "post": rp })}`)} </div> </section>`} </div> ` })}`;
}, "/Users/alex/Library/Mobile Documents/com~apple~CloudDocs/Dev/NotSoCommonThoughts/src/pages/blog/[...slug].astro", void 0);

const $$file = "/Users/alex/Library/Mobile Documents/com~apple~CloudDocs/Dev/NotSoCommonThoughts/src/pages/blog/[...slug].astro";
const $$url = "/blog/[...slug]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
