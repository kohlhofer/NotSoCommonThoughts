import { c as createAstro, a as createComponent, b as addAttribute, r as renderHead, d as renderScript, e as renderTemplate } from '../chunks/astro/server_C4BCxsMS.mjs';
import 'kleur/colors';
import 'clsx';
/* empty css                                      */
/* empty css                               */
export { renderers } from '../renderers.mjs';

const $$Astro = createAstro("https://notsocommonthoughts.com");
const $$404 = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$404;
  return renderTemplate`<html lang="en" data-astro-cid-zetdm5md> <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><link rel="icon" type="image/svg+xml" href="/favicon.svg"><meta name="generator"${addAttribute(Astro2.generator, "content")}><meta name="description" content="Page not found - Not So Common Thoughts"><title>404 - Page Not Found</title>${renderHead()}</head> <body data-astro-cid-zetdm5md> <div class="page-container" data-astro-cid-zetdm5md> <a href="/" class="site-title font-sans font-bold font-outfit embossed bg-gradient-to-r from-red-400 via-pink-500 to-purple-500 bg-clip-text text-transparent hover:text-red-400 transition-colors" data-astro-cid-zetdm5md>Not So Common Thoughts</a> <div class="error-code" data-astro-cid-zetdm5md>404</div> <div class="error-message" data-astro-cid-zetdm5md>Oops! The page you're looking for doesn't exist.</div> <div class="button-container" data-astro-cid-zetdm5md> <a href="/" class="button-primary" data-astro-cid-zetdm5md> <svg class="icon" viewBox="0 0 20 20" fill="currentColor" data-astro-cid-zetdm5md> <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" data-astro-cid-zetdm5md></path> </svg>
Home
</a> <button onclick="history.back()" class="button-secondary" data-astro-cid-zetdm5md> <svg class="icon" viewBox="0 0 20 20" fill="currentColor" data-astro-cid-zetdm5md> <path fill-rule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clip-rule="evenodd" data-astro-cid-zetdm5md></path> </svg>
Go Back
</button> </div> </div> ${renderScript($$result, "/Users/alex/Library/Mobile Documents/com~apple~CloudDocs/Dev/NotSoCommonThoughts/src/pages/404.astro?astro&type=script&index=0&lang.ts")} </body> </html>`;
}, "/Users/alex/Library/Mobile Documents/com~apple~CloudDocs/Dev/NotSoCommonThoughts/src/pages/404.astro", void 0);

const $$file = "/Users/alex/Library/Mobile Documents/com~apple~CloudDocs/Dev/NotSoCommonThoughts/src/pages/404.astro";
const $$url = "/404";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$404,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
